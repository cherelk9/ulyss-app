"use client"

import { createContext, useState, useContext, useEffect } from "react"
import { toast } from "react-toastify"
import { loginUser, registerUser, getCurrentUser, logoutUser } from "../services/authService"

const AuthContext = createContext()

export function useAuth() {
  return useContext(AuthContext)
}

export function AuthProvider({ children }) {
  const [currentUser, setCurrentUser] = useState(null)
  const [isLoading, setIsLoading] = useState(true)

  useEffect(() => {
    // Check if user is already logged in
    const checkLoggedIn = async () => {
      try {
        const user = await getCurrentUser()
        setCurrentUser(user)
      } catch (error) {
        console.error("Error checking authentication:", error)
      } finally {
        setIsLoading(false)
      }
    }

    checkLoggedIn()
  }, [])

  const login = async (email, password) => {
    try {
      setIsLoading(true)
      const user = await loginUser(email, password)
      setCurrentUser(user)
      toast.success("Connexion réussie!")
      return user
    } catch (error) {
      toast.error(error.message || "Échec de la connexion")
      throw error
    } finally {
      setIsLoading(false)
    }
  }

  const register = async (userData) => {
    try {
      setIsLoading(true)
      const user = await registerUser(userData)
      setCurrentUser(user)
      toast.success("Inscription réussie!")
      return user
    } catch (error) {
      toast.error(error.message || "Échec de l'inscription")
      throw error
    } finally {
      setIsLoading(false)
    }
  }

  const logout = async () => {
    try {
      setIsLoading(true)
      await logoutUser()
      setCurrentUser(null)
      toast.success("Déconnexion réussie!")
    } catch (error) {
      toast.error(error.message || "Échec de la déconnexion")
      throw error
    } finally {
      setIsLoading(false)
    }
  }

  const value = {
    currentUser,
    isLoading,
    login,
    register,
    logout,
  }

  return <AuthContext.Provider value={value}>{children}</AuthContext.Provider>
}
