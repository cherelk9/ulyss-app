"use client"
import { BrowserRouter as Router, Routes, Route, Navigate } from "react-router-dom"
import { ToastContainer } from "react-toastify"
import "react-toastify/dist/ReactToastify.css"
import { AuthProvider, useAuth } from "./contexts/AuthContext"
import { ThemeProvider } from "./contexts/ThemeContext"

// Layouts
import MainLayout from "./layouts/MainLayout"
import AdminLayout from "./layouts/AdminLayout"

// Public Pages
import HomePage from "./pages/public/HomePage"
import LoginPage from "./pages/public/LoginPage"
import RegisterPage from "./pages/public/RegisterPage"
import ListingDetailsPage from "./pages/public/ListingDetailsPage"
import SearchResultsPage from "./pages/public/SearchResultsPage"
import CategoryListingsPage from "./pages/public/CategoryListingsPage"

// Client Pages
import ClientDashboard from "./pages/client/ClientDashboard"
import ClientOrders from "./pages/client/ClientOrders"
import ClientOrderDetails from "./pages/client/ClientOrderDetails"
import ClientProfile from "./pages/client/ClientProfile"

// Proprietaire Pages
import ProprietaireDashboard from "./pages/proprietaire/ProprietaireDashboard"
import ProprietaireListings from "./pages/proprietaire/ProprietaireListings"
import ProprietaireCreateListing from "./pages/proprietaire/ProprietaireCreateListing"
import ProprietaireEditListing from "./pages/proprietaire/ProprietaireEditListing"
import ProprietaireOrders from "./pages/proprietaire/ProprietaireOrders"
import ProprietaireProfile from "./pages/proprietaire/ProprietaireProfile"
import ProprietairePayments from "./pages/proprietaire/ProprietairePayments"

// Admin Pages
import AdminDashboard from "./pages/admin/AdminDashboard"
import AdminUsers from "./pages/admin/AdminUsers"
import AdminListings from "./pages/admin/AdminListings"
import AdminOrders from "./pages/admin/AdminOrders"
import AdminPayments from "./pages/admin/AdminPayments"
import AdminCategories from "./pages/admin/AdminCategories"
import AdminSettings from "./pages/admin/AdminSettings"

// Protected Route Component
const ProtectedRoute = ({ children, allowedRoles }) => {
  const { currentUser, isLoading } = useAuth()

  if (isLoading) {
    return <div className="loading-spinner">Chargement...</div>
  }

  if (!currentUser) {
    return <Navigate to="/login" />
  }

  if (allowedRoles && !allowedRoles.includes(currentUser.role)) {
    return <Navigate to="/" />
  }

  return children
}

function App() {
  return (
    <ThemeProvider>
      <AuthProvider>
        <Router>
          <Routes>
            {/* Public Routes */}
            <Route path="/" element={<MainLayout />}>
              <Route index element={<HomePage />} />
              <Route path="login" element={<LoginPage />} />
              <Route path="register" element={<RegisterPage />} />
              <Route path="listings/:id" element={<ListingDetailsPage />} />
              <Route path="search" element={<SearchResultsPage />} />
              <Route path="category/:id" element={<CategoryListingsPage />} />

              {/* Client Routes */}
              <Route
                path="client/dashboard"
                element={
                  <ProtectedRoute allowedRoles={["client"]}>
                    <ClientDashboard />
                  </ProtectedRoute>
                }
              />
              <Route
                path="client/orders"
                element={
                  <ProtectedRoute allowedRoles={["client"]}>
                    <ClientOrders />
                  </ProtectedRoute>
                }
              />
              <Route
                path="client/orders/:id"
                element={
                  <ProtectedRoute allowedRoles={["client"]}>
                    <ClientOrderDetails />
                  </ProtectedRoute>
                }
              />
              <Route
                path="client/profile"
                element={
                  <ProtectedRoute allowedRoles={["client"]}>
                    <ClientProfile />
                  </ProtectedRoute>
                }
              />

              {/* Proprietaire Routes */}
              <Route
                path="proprietaire/dashboard"
                element={
                  <ProtectedRoute allowedRoles={["proprietaire"]}>
                    <ProprietaireDashboard />
                  </ProtectedRoute>
                }
              />
              <Route
                path="proprietaire/listings"
                element={
                  <ProtectedRoute allowedRoles={["proprietaire"]}>
                    <ProprietaireListings />
                  </ProtectedRoute>
                }
              />
              <Route
                path="proprietaire/listings/create"
                element={
                  <ProtectedRoute allowedRoles={["proprietaire"]}>
                    <ProprietaireCreateListing />
                  </ProtectedRoute>
                }
              />
              <Route
                path="proprietaire/listings/edit/:id"
                element={
                  <ProtectedRoute allowedRoles={["proprietaire"]}>
                    <ProprietaireEditListing />
                  </ProtectedRoute>
                }
              />
              <Route
                path="proprietaire/orders"
                element={
                  <ProtectedRoute allowedRoles={["proprietaire"]}>
                    <ProprietaireOrders />
                  </ProtectedRoute>
                }
              />
              <Route
                path="proprietaire/profile"
                element={
                  <ProtectedRoute allowedRoles={["proprietaire"]}>
                    <ProprietaireProfile />
                  </ProtectedRoute>
                }
              />
              <Route
                path="proprietaire/payments"
                element={
                  <ProtectedRoute allowedRoles={["proprietaire"]}>
                    <ProprietairePayments />
                  </ProtectedRoute>
                }
              />
            </Route>

            {/* Admin Routes */}
            <Route
              path="/admin"
              element={
                <ProtectedRoute allowedRoles={["admin"]}>
                  <AdminLayout />
                </ProtectedRoute>
              }
            >
              <Route index element={<AdminDashboard />} />
              <Route path="users" element={<AdminUsers />} />
              <Route path="listings" element={<AdminListings />} />
              <Route path="orders" element={<AdminOrders />} />
              <Route path="payments" element={<AdminPayments />} />
              <Route path="categories" element={<AdminCategories />} />
              <Route path="settings" element={<AdminSettings />} />
            </Route>
          </Routes>
        </Router>
        <ToastContainer position="bottom-right" autoClose={3000} />
      </AuthProvider>
    </ThemeProvider>
  )
}

export default App
