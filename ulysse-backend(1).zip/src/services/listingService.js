// Simulating listing service with mock data
import { mockListings, mockCategories } from "../data/mockData"

// Simulate API delay
const delay = (ms) => new Promise((resolve) => setTimeout(resolve, ms))

// Get all listings
export const getAllListings = async (filters = {}) => {
  await delay(800) // Simulate API call

  let filteredListings = [...mockListings]

  // Apply filters
  if (filters.status) {
    filteredListings = filteredListings.filter((listing) => listing.status === filters.status)
  }

  if (filters.categoryId) {
    filteredListings = filteredListings.filter((listing) => listing.categoryId === Number.parseInt(filters.categoryId))
  }

  if (filters.ownerId) {
    filteredListings = filteredListings.filter((listing) => listing.ownerId === filters.ownerId)
  }

  if (filters.search) {
    const searchTerm = filters.search.toLowerCase()
    filteredListings = filteredListings.filter(
      (listing) =>
        listing.name.toLowerCase().includes(searchTerm) || listing.description.toLowerCase().includes(searchTerm),
    )
  }

  // Sort listings
  if (filters.sort) {
    switch (filters.sort) {
      case "price_asc":
        filteredListings.sort((a, b) => a.price - b.price)
        break
      case "price_desc":
        filteredListings.sort((a, b) => b.price - a.price)
        break
      case "date_desc":
        filteredListings.sort((a, b) => new Date(b.createdAt) - new Date(a.createdAt))
        break
      case "date_asc":
        filteredListings.sort((a, b) => new Date(a.createdAt) - new Date(b.createdAt))
        break
      default:
        break
    }
  }

  // Pagination
  const page = filters.page || 1
  const limit = filters.limit || 10
  const startIndex = (page - 1) * limit
  const endIndex = page * limit

  const paginatedListings = filteredListings.slice(startIndex, endIndex)

  return {
    listings: paginatedListings,
    total: filteredListings.length,
    page: Number.parseInt(page),
    limit: Number.parseInt(limit),
    totalPages: Math.ceil(filteredListings.length / limit),
  }
}

// Get listing by ID
export const getListingById = async (id) => {
  await delay(500) // Simulate API call

  const listing = mockListings.find((listing) => listing.id === Number.parseInt(id))

  if (!listing) {
    throw new Error("Annonce non trouvée")
  }

  // Get category
  const category = mockCategories.find((cat) => cat.id === listing.categoryId)

  return {
    ...listing,
    category,
  }
}

// Create listing
export const createListing = async (listingData, ownerId, ownerName) => {
  await delay(1000) // Simulate API call

  const newListing = {
    id: mockListings.length + 1,
    ...listingData,
    ownerId,
    ownerName,
    status: "PENDING",
    createdAt: new Date().toISOString(),
    updatedAt: new Date().toISOString(),
    viewCount: 0,
    featured: false,
  }

  // Add to mock data
  mockListings.push(newListing)

  return newListing
}

// Update listing
export const updateListing = async (id, listingData) => {
  await delay(1000) // Simulate API call

  const listingIndex = mockListings.findIndex((listing) => listing.id === Number.parseInt(id))

  if (listingIndex === -1) {
    throw new Error("Annonce non trouvée")
  }

  // Update listing
  mockListings[listingIndex] = {
    ...mockListings[listingIndex],
    ...listingData,
    updatedAt: new Date().toISOString(),
    status: "PENDING", // Reset status to pending after update
  }

  return mockListings[listingIndex]
}

// Delete listing
export const deleteListing = async (id) => {
  await delay(1000) // Simulate API call

  const listingIndex = mockListings.findIndex((listing) => listing.id === Number.parseInt(id))

  if (listingIndex === -1) {
    throw new Error("Annonce non trouvée")
  }

  // Remove from mock data
  mockListings.splice(listingIndex, 1)

  return { success: true }
}

// Update listing status
export const updateListingStatus = async (id, status, rejectionReason = null) => {
  await delay(800) // Simulate API call

  const listingIndex = mockListings.findIndex((listing) => listing.id === Number.parseInt(id))

  if (listingIndex === -1) {
    throw new Error("Annonce non trouvée")
  }

  // Update status
  mockListings[listingIndex] = {
    ...mockListings[listingIndex],
    status,
    rejectionReason: status === "REJECTED" ? rejectionReason : null,
    updatedAt: new Date().toISOString(),
  }

  return mockListings[listingIndex]
}

// Get all categories
export const getAllCategories = async () => {
  await delay(500) // Simulate API call
  return mockCategories
}

// Get featured listings
export const getFeaturedListings = async (limit = 6) => {
  await delay(500) // Simulate API call

  const featuredListings = mockListings
    .filter((listing) => listing.featured && listing.status === "APPROVED")
    .slice(0, limit)

  return featuredListings
}

// Toggle featured status
export const toggleFeaturedStatus = async (id, featured) => {
  await delay(800) // Simulate API call

  const listingIndex = mockListings.findIndex((listing) => listing.id === Number.parseInt(id))

  if (listingIndex === -1) {
    throw new Error("Annonce non trouvée")
  }

  // Update featured status
  mockListings[listingIndex] = {
    ...mockListings[listingIndex],
    featured,
    updatedAt: new Date().toISOString(),
  }

  return mockListings[listingIndex]
}
