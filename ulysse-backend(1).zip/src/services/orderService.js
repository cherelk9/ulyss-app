// Simulating order service with mock data
import { mockOrders, mockListings } from "../data/mockData"

// Simulate API delay
const delay = (ms) => new Promise((resolve) => setTimeout(resolve, ms))

// Get all orders
export const getAllOrders = async (filters = {}) => {
  await delay(800) // Simulate API call

  let filteredOrders = [...mockOrders]

  // Apply filters
  if (filters.status) {
    filteredOrders = filteredOrders.filter((order) => order.status === filters.status)
  }

  if (filters.clientId) {
    filteredOrders = filteredOrders.filter((order) => order.clientId === filters.clientId)
  }

  if (filters.proprietaireId) {
    filteredOrders = filteredOrders.filter((order) => order.proprietaireId === filters.proprietaireId)
  }

  // Sort orders
  if (filters.sort) {
    switch (filters.sort) {
      case "date_desc":
        filteredOrders.sort((a, b) => new Date(b.orderDate) - new Date(a.orderDate))
        break
      case "date_asc":
        filteredOrders.sort((a, b) => new Date(a.orderDate) - new Date(b.orderDate))
        break
      case "amount_desc":
        filteredOrders.sort((a, b) => b.amount - a.amount)
        break
      case "amount_asc":
        filteredOrders.sort((a, b) => a.amount - b.amount)
        break
      default:
        break
    }
  } else {
    // Default sort by date descending
    filteredOrders.sort((a, b) => new Date(b.orderDate) - new Date(a.orderDate))
  }

  // Pagination
  const page = filters.page || 1
  const limit = filters.limit || 10
  const startIndex = (page - 1) * limit
  const endIndex = page * limit

  const paginatedOrders = filteredOrders.slice(startIndex, endIndex)

  return {
    orders: paginatedOrders,
    total: filteredOrders.length,
    page: Number.parseInt(page),
    limit: Number.parseInt(limit),
    totalPages: Math.ceil(filteredOrders.length / limit),
  }
}

// Get order by ID
export const getOrderById = async (id) => {
  await delay(500) // Simulate API call

  const order = mockOrders.find((order) => order.id === Number.parseInt(id))

  if (!order) {
    throw new Error("Commande non trouvée")
  }

  return order
}

// Create order
export const createOrder = async (orderData) => {
  await delay(1000) // Simulate API call

  // Get listing
  const listing = mockListings.find((listing) => listing.id === orderData.listingId)

  if (!listing) {
    throw new Error("Annonce non trouvée")
  }

  // Calculate commission (10%)
  const commissionAmount = listing.price * 0.1

  const newOrder = {
    id: mockOrders.length + 1,
    clientId: orderData.clientId,
    clientName: orderData.clientName,
    proprietaireId: listing.ownerId,
    proprietaireName: listing.ownerName,
    listingId: listing.id,
    listingName: listing.name,
    amount: listing.price,
    commissionAmount,
    status: "PENDING",
    paymentMethod: orderData.paymentMethod || null,
    paymentReference: null,
    orderDate: new Date().toISOString(),
    paymentDate: null,
    completionDate: null,
  }

  // Add to mock data
  mockOrders.push(newOrder)

  return newOrder
}

// Process payment
export const processPayment = async (orderId, paymentData) => {
  await delay(1500) // Simulate API call

  const orderIndex = mockOrders.findIndex((order) => order.id === Number.parseInt(orderId))

  if (orderIndex === -1) {
    throw new Error("Commande non trouvée")
  }

  // Update order with payment info
  mockOrders[orderIndex] = {
    ...mockOrders[orderIndex],
    status: "PAID",
    paymentMethod: paymentData.paymentMethod,
    paymentReference: `PAY-${Date.now()}`,
    paymentDate: new Date().toISOString(),
  }

  return mockOrders[orderIndex]
}

// Complete order
export const completeOrder = async (orderId) => {
  await delay(800) // Simulate API call

  const orderIndex = mockOrders.findIndex((order) => order.id === Number.parseInt(orderId))

  if (orderIndex === -1) {
    throw new Error("Commande non trouvée")
  }

  if (mockOrders[orderIndex].status !== "PAID") {
    throw new Error("La commande doit être payée avant d'être complétée")
  }

  // Update order status
  mockOrders[orderIndex] = {
    ...mockOrders[orderIndex],
    status: "COMPLETED",
    completionDate: new Date().toISOString(),
  }

  return mockOrders[orderIndex]
}

// Cancel order
export const cancelOrder = async (orderId) => {
  await delay(800) // Simulate API call

  const orderIndex = mockOrders.findIndex((order) => order.id === Number.parseInt(orderId))

  if (orderIndex === -1) {
    throw new Error("Commande non trouvée")
  }

  if (mockOrders[orderIndex].status === "COMPLETED") {
    throw new Error("Impossible d'annuler une commande déjà complétée")
  }

  // Update order status
  mockOrders[orderIndex] = {
    ...mockOrders[orderIndex],
    status: "CANCELLED",
  }

  return mockOrders[orderIndex]
}

// Get order statistics
export const getOrderStatistics = async (userId = null, role = null) => {
  await delay(800) // Simulate API call

  let filteredOrders = [...mockOrders]

  // Filter by user if provided
  if (userId && role) {
    if (role === "client") {
      filteredOrders = filteredOrders.filter((order) => order.clientId === userId)
    } else if (role === "proprietaire") {
      filteredOrders = filteredOrders.filter((order) => order.proprietaireId === userId)
    }
  }

  // Calculate statistics
  const totalOrders = filteredOrders.length
  const pendingOrders = filteredOrders.filter((order) => order.status === "PENDING").length
  const paidOrders = filteredOrders.filter((order) => order.status === "PAID").length
  const completedOrders = filteredOrders.filter((order) => order.status === "COMPLETED").length
  const cancelledOrders = filteredOrders.filter((order) => order.status === "CANCELLED").length

  const totalRevenue = filteredOrders
    .filter((order) => ["PAID", "COMPLETED"].includes(order.status))
    .reduce((sum, order) => sum + order.amount, 0)

  const totalCommission = filteredOrders
    .filter((order) => ["PAID", "COMPLETED"].includes(order.status))
    .reduce((sum, order) => sum + order.commissionAmount, 0)

  return {
    totalOrders,
    pendingOrders,
    paidOrders,
    completedOrders,
    cancelledOrders,
    totalRevenue,
    totalCommission,
  }
}
