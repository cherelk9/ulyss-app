// Simulating authentication service with mock data
import { mockUsers } from "../data/mockData"

// Simulate API delay
const delay = (ms) => new Promise((resolve) => setTimeout(resolve, ms))

// Get user from localStorage
const getStoredUser = () => {
  const user = localStorage.getItem("user")
  return user ? JSON.parse(user) : null
}

// Store user in localStorage
const storeUser = (user) => {
  localStorage.setItem("user", JSON.stringify(user))
}

// Remove user from localStorage
const removeUser = () => {
  localStorage.removeItem("user")
}

// Login user
export const loginUser = async (email, password) => {
  await delay(1000) // Simulate API call

  const user = mockUsers.find((user) => user.email === email && user.password === password)

  if (!user) {
    throw new Error("Email ou mot de passe incorrect")
  }

  // Don't include password in the returned user object
  const { password: _, ...userWithoutPassword } = user

  // Store user in localStorage
  storeUser(userWithoutPassword)

  return userWithoutPassword
}

// Register user
export const registerUser = async (userData) => {
  await delay(1000) // Simulate API call

  // Check if email already exists
  const existingUser = mockUsers.find((user) => user.email === userData.email)
  if (existingUser) {
    throw new Error("Cet email est déjà utilisé")
  }

  // Create new user
  const newUser = {
    id: mockUsers.length + 1,
    ...userData,
    createdAt: new Date().toISOString(),
  }

  // Add to mock data (in a real app, this would be an API call)
  mockUsers.push(newUser)

  // Don't include password in the returned user object
  const { password: _, ...userWithoutPassword } = newUser

  // Store user in localStorage
  storeUser(userWithoutPassword)

  return userWithoutPassword
}

// Get current user
export const getCurrentUser = async () => {
  await delay(500) // Simulate API call
  return getStoredUser()
}

// Logout user
export const logoutUser = async () => {
  await delay(500) // Simulate API call
  removeUser()
}

// Update user profile
export const updateUserProfile = async (userId, userData) => {
  await delay(1000) // Simulate API call

  const userIndex = mockUsers.findIndex((user) => user.id === userId)
  if (userIndex === -1) {
    throw new Error("Utilisateur non trouvé")
  }

  // Update user in mock data
  mockUsers[userIndex] = {
    ...mockUsers[userIndex],
    ...userData,
    updatedAt: new Date().toISOString(),
  }

  // Don't include password in the returned user object
  const { password: _, ...userWithoutPassword } = mockUsers[userIndex]

  // Update stored user
  storeUser(userWithoutPassword)

  return userWithoutPassword
}
