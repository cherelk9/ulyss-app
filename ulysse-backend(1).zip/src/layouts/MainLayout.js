"use client"

import { useState } from "react"
import { Outlet, Link, useNavigate } from "react-router-dom"
import { FaSearch, FaBars, FaTimes, FaUser, FaSignOutAlt, FaUserCog } from "react-icons/fa"
import { useAuth } from "../contexts/AuthContext"
import { useTheme } from "../contexts/ThemeContext"
import "./MainLayout.css"

const MainLayout = () => {
  const { currentUser, logout } = useAuth()
  const { darkMode, toggleDarkMode } = useTheme()
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false)
  const [searchQuery, setSearchQuery] = useState("")
  const navigate = useNavigate()

  const handleSearch = (e) => {
    e.preventDefault()
    if (searchQuery.trim()) {
      navigate(`/search?q=${encodeURIComponent(searchQuery)}`)
      setSearchQuery("")
    }
  }

  const toggleMobileMenu = () => {
    setMobileMenuOpen(!mobileMenuOpen)
  }

  const handleLogout = async () => {
    try {
      await logout()
      navigate("/")
    } catch (error) {
      console.error("Logout error:", error)
    }
  }

  return (
    <div className={`main-layout ${darkMode ? "dark-mode" : ""}`}>
      <header className="header">
        <div className="container">
          <div className="header-content">
            <div className="logo">
              <Link to="/">
                <h1>ULYSSE</h1>
              </Link>
            </div>

            <form className="search-form" onSubmit={handleSearch}>
              <input
                type="text"
                placeholder="Rechercher des services..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
              />
              <button type="submit">
                <FaSearch />
              </button>
            </form>

            <nav className={`main-nav ${mobileMenuOpen ? "active" : ""}`}>
              <ul>
                <li>
                  <Link to="/">Accueil</Link>
                </li>
                <li>
                  <Link to="/search">Services</Link>
                </li>
                {currentUser ? (
                  <>
                    {currentUser.role === "client" && (
                      <>
                        <li>
                          <Link to="/client/dashboard">Tableau de bord</Link>
                        </li>
                        <li>
                          <Link to="/client/orders">Mes commandes</Link>
                        </li>
                      </>
                    )}
                    {currentUser.role === "proprietaire" && (
                      <>
                        <li>
                          <Link to="/proprietaire/dashboard">Tableau de bord</Link>
                        </li>
                        <li>
                          <Link to="/proprietaire/listings">Mes annonces</Link>
                        </li>
                        <li>
                          <Link to="/proprietaire/orders">Commandes reçues</Link>
                        </li>
                      </>
                    )}
                    {currentUser.role === "admin" && (
                      <li>
                        <Link to="/admin">Administration</Link>
                      </li>
                    )}
                    <li className="dropdown">
                      <button className="dropdown-toggle">
                        <FaUser /> {currentUser.fullName}
                      </button>
                      <ul className="dropdown-menu">
                        {currentUser.role === "client" && (
                          <li>
                            <Link to="/client/profile">
                              <FaUserCog /> Mon profil
                            </Link>
                          </li>
                        )}
                        {currentUser.role === "proprietaire" && (
                          <li>
                            <Link to="/proprietaire/profile">
                              <FaUserCog /> Mon profil
                            </Link>
                          </li>
                        )}
                        <li>
                          <button onClick={handleLogout}>
                            <FaSignOutAlt /> Déconnexion
                          </button>
                        </li>
                      </ul>
                    </li>
                  </>
                ) : (
                  <>
                    <li>
                      <Link to="/login" className="btn btn-outline-primary">
                        Connexion
                      </Link>
                    </li>
                    <li>
                      <Link to="/register" className="btn btn-primary">
                        Inscription
                      </Link>
                    </li>
                  </>
                )}
              </ul>
            </nav>

            <div className="mobile-menu-toggle" onClick={toggleMobileMenu}>
              {mobileMenuOpen ? <FaTimes /> : <FaBars />}
            </div>
          </div>
        </div>
      </header>

      <main className="main-content">
        <Outlet />
      </main>

      <footer className="footer">
        <div className="container">
          <div className="footer-content">
            <div className="footer-logo">
              <h2>ULYSSE</h2>
              <p>Votre plateforme de services</p>
            </div>
            <div className="footer-links">
              <h3>Liens rapides</h3>
              <ul>
                <li>
                  <Link to="/">Accueil</Link>
                </li>
                <li>
                  <Link to="/search">Services</Link>
                </li>
                <li>
                  <Link to="/login">Connexion</Link>
                </li>
                <li>
                  <Link to="/register">Inscription</Link>
                </li>
              </ul>
            </div>
            <div className="footer-contact">
              <h3>Contact</h3>
              <p>Email: contact@ulysse.com</p>
              <p>Téléphone: +123 456 789</p>
              <p>Adresse: 123 Rue Exemple, Ville, Pays</p>
            </div>
          </div>
          <div className="footer-bottom">
            <p>&copy; {new Date().getFullYear()} ULYSSE. Tous droits réservés.</p>
          </div>
        </div>
      </footer>
    </div>
  )
}

export default MainLayout
