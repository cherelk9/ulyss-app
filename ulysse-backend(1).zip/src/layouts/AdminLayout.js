"use client"

import { useState } from "react"
import { Outlet, Link, useNavigate, useLocation } from "react-router-dom"
import {
  FaHome,
  FaUsers,
  FaList,
  FaShoppingCart,
  FaCreditCard,
  FaTags,
  FaCog,
  FaSignOutAlt,
  FaBars,
  FaTimes,
  FaUser,
} from "react-icons/fa"
import { useAuth } from "../contexts/AuthContext"
import { useTheme } from "../contexts/ThemeContext"
import "./AdminLayout.css"

const AdminLayout = () => {
  const { currentUser, logout } = useAuth()
  const { darkMode, toggleDarkMode } = useTheme()
  const [sidebarOpen, setSidebarOpen] = useState(true)
  const navigate = useNavigate()
  const location = useLocation()

  const handleLogout = async () => {
    try {
      await logout()
      navigate("/")
    } catch (error) {
      console.error("Logout error:", error)
    }
  }

  const toggleSidebar = () => {
    setSidebarOpen(!sidebarOpen)
  }

  const isActive = (path) => {
    return location.pathname === path
  }

  if (!currentUser || currentUser.role !== "admin") {
    navigate("/login")
    return null
  }

  return (
    <div className={`admin-layout ${darkMode ? "dark-mode" : ""}`}>
      <div className={`sidebar ${sidebarOpen ? "open" : "closed"}`}>
        <div className="sidebar-header">
          <h2>ULYSSE</h2>
          <button className="sidebar-toggle" onClick={toggleSidebar}>
            {sidebarOpen ? <FaTimes /> : <FaBars />}
          </button>
        </div>
        <div className="sidebar-user">
          <div className="user-avatar">
            <FaUser />
          </div>
          <div className="user-info">
            <h3>{currentUser.fullName}</h3>
            <p>Administrateur</p>
          </div>
        </div>
        <nav className="sidebar-nav">
          <ul>
            <li className={isActive("/admin") ? "active" : ""}>
              <Link to="/admin">
                <FaHome /> <span>Tableau de bord</span>
              </Link>
            </li>
            <li className={isActive("/admin/users") ? "active" : ""}>
              <Link to="/admin/users">
                <FaUsers /> <span>Utilisateurs</span>
              </Link>
            </li>
            <li className={isActive("/admin/listings") ? "active" : ""}>
              <Link to="/admin/listings">
                <FaList /> <span>Annonces</span>
              </Link>
            </li>
            <li className={isActive("/admin/orders") ? "active" : ""}>
              <Link to="/admin/orders">
                <FaShoppingCart /> <span>Commandes</span>
              </Link>
            </li>
            <li className={isActive("/admin/payments") ? "active" : ""}>
              <Link to="/admin/payments">
                <FaCreditCard /> <span>Paiements</span>
              </Link>
            </li>
            <li className={isActive("/admin/categories") ? "active" : ""}>
              <Link to="/admin/categories">
                <FaTags /> <span>Catégories</span>
              </Link>
            </li>
            <li className={isActive("/admin/settings") ? "active" : ""}>
              <Link to="/admin/settings">
                <FaCog /> <span>Paramètres</span>
              </Link>
            </li>
          </ul>
        </nav>
        <div className="sidebar-footer">
          <button onClick={handleLogout}>
            <FaSignOutAlt /> <span>Déconnexion</span>
          </button>
        </div>
      </div>
      <div className="admin-content">
        <header className="admin-header">
          <button className="mobile-sidebar-toggle" onClick={toggleSidebar}>
            <FaBars />
          </button>
          <div className="header-actions">
            <button className="theme-toggle" onClick={toggleDarkMode}>
              {darkMode ? "Mode clair" : "Mode sombre"}
            </button>
          </div>
        </header>
        <main className="admin-main">
          <Outlet />
        </main>
      </div>
    </div>
  )
}

export default AdminLayout
