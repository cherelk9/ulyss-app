"use client"

import { useState, useEffect } from "react"
import { Link } from "react-router-dom"
import { FaUsers, FaList, FaShoppingCart, FaCreditCard, FaExclamationTriangle, FaCheckCircle } from "react-icons/fa"
import { mockStatistics } from "../../data/mockData"
import "./AdminDashboard.css"

const AdminDashboard = () => {
  const [statistics, setStatistics] = useState(null)
  const [isLoading, setIsLoading] = useState(true)
  const [timeframe, setTimeframe] = useState("month")

  useEffect(() => {
    // Simulate API call to get statistics
    const fetchStatistics = async () => {
      try {
        setIsLoading(true)
        // In a real app, this would be an API call
        await new Promise((resolve) => setTimeout(resolve, 1000))
        setStatistics(mockStatistics)
      } catch (error) {
        console.error("Error fetching statistics:", error)
      } finally {
        setIsLoading(false)
      }
    }

    fetchStatistics()
  }, [timeframe])

  if (isLoading) {
    return <div className="loading">Chargement des statistiques...</div>
  }

  return (
    <div className="admin-dashboard">
      <div className="dashboard-header">
        <h1>Tableau de bord</h1>
        <div className="timeframe-selector">
          <button className={timeframe === "week" ? "active" : ""} onClick={() => setTimeframe("week")}>
            Semaine
          </button>
          <button className={timeframe === "month" ? "active" : ""} onClick={() => setTimeframe("month")}>
            Mois
          </button>
          <button className={timeframe === "year" ? "active" : ""} onClick={() => setTimeframe("year")}>
            Année
          </button>
        </div>
      </div>

      <div className="stats-cards">
        <div className="stat-card">
          <div className="stat-icon users">
            <FaUsers />
          </div>
          <div className="stat-content">
            <h3>Utilisateurs</h3>
            <div className="stat-value">{statistics.users.total}</div>
            <div className="stat-details">
              <span>Clients: {statistics.users.clients}</span>
              <span>Propriétaires: {statistics.users.proprietaires}</span>
              <span>Admins: {statistics.users.admins}</span>
            </div>
          </div>
        </div>

        <div className="stat-card">
          <div className="stat-icon listings">
            <FaList />
          </div>
          <div className="stat-content">
            <h3>Annonces</h3>
            <div className="stat-value">{statistics.listings.total}</div>
            <div className="stat-details">
              <span>Approuvées: {statistics.listings.approved}</span>
              <span>En attente: {statistics.listings.pending}</span>
              <span>Refusées: {statistics.listings.rejected}</span>
            </div>
          </div>
        </div>

        <div className="stat-card">
          <div className="stat-icon orders">
            <FaShoppingCart />
          </div>
          <div className="stat-content">
            <h3>Commandes</h3>
            <div className="stat-value">{statistics.orders.total}</div>
            <div className="stat-details">
              <span>En attente: {statistics.orders.pending}</span>
              <span>Payées: {statistics.orders.paid}</span>
              <span>Complétées: {statistics.orders.completed}</span>
            </div>
          </div>
        </div>

        <div className="stat-card">
          <div className="stat-icon revenue">
            <FaCreditCard />
          </div>
          <div className="stat-content">
            <h3>Revenus</h3>
            <div className="stat-value">{statistics.orders.totalRevenue} XOF</div>
            <div className="stat-details">
              <span>Commissions: {statistics.orders.totalCommission} XOF</span>
            </div>
          </div>
        </div>
      </div>

      <div className="dashboard-row">
        <div className="dashboard-card recent-activity">
          <div className="card-header">
            <h2>Activité récente</h2>
            <Link to="/admin/orders" className="view-all">
              Voir tout
            </Link>
          </div>
          <div className="card-content">
            <div className="activity-item">
              <div className="activity-icon pending">
                <FaExclamationTriangle />
              </div>
              <div className="activity-content">
                <h4>Nouvelle commande #5</h4>
                <p>Sophie Petit a commandé "Excursion île de Gorée"</p>
                <span className="activity-time">Il y a 2 heures</span>
              </div>
              <div className="activity-status pending">En attente</div>
            </div>
            <div className="activity-item">
              <div className="activity-icon success">
                <FaCheckCircle />
              </div>
              <div className="activity-content">
                <h4>Paiement reçu #2</h4>
                <p>Marie Martin a payé pour "Location de voiture économique"</p>
                <span className="activity-time">Il y a 5 heures</span>
              </div>
              <div className="activity-status success">Payée</div>
            </div>
            <div className="activity-item">
              <div className="activity-icon success">
                <FaCheckCircle />
              </div>
              <div className="activity-content">
                <h4>Commande complétée #1</h4>
                <p>Marie Martin a complété "Appartement vue mer"</p>
                <span className="activity-time">Il y a 1 jour</span>
              </div>
              <div className="activity-status success">Complétée</div>
            </div>
          </div>
        </div>

        <div className="dashboard-card pending-approvals">
          <div className="card-header">
            <h2>Approbations en attente</h2>
            <Link to="/admin/listings" className="view-all">
              Voir tout
            </Link>
          </div>
          <div className="card-content">
            <div className="approval-item">
              <div className="approval-content">
                <h4>Villa de luxe avec piscine</h4>
                <p>Soumis par Pierre Durand</p>
                <span className="approval-time">Il y a 3 jours</span>
              </div>
              <div className="approval-actions">
                <button className="btn btn-success btn-sm">Approuver</button>
                <button className="btn btn-danger btn-sm">Refuser</button>
              </div>
            </div>
          </div>
        </div>
      </div>

      <div className="dashboard-row">
        <div className="dashboard-card category-distribution">
          <div className="card-header">
            <h2>Distribution par catégorie</h2>
          </div>
          <div className="card-content">
            <div className="category-chart">
              {statistics.categories.distribution.map((category, index) => (
                <div className="category-bar" key={index}>
                  <div className="category-name">{category.name}</div>
                  <div className="bar-container">
                    <div
                      className="bar"
                      style={{
                        width: `${(category.count / statistics.listings.total) * 100}%`,
                        backgroundColor: getColorForIndex(index),
                      }}
                    ></div>
                    <span className="bar-value">{category.count}</span>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>

        <div className="dashboard-card quick-actions">
          <div className="card-header">
            <h2>Actions rapides</h2>
          </div>
          <div className="card-content">
            <div className="quick-actions-grid">
              <Link to="/admin/users" className="quick-action-card">
                <FaUsers />
                <span>Gérer les utilisateurs</span>
              </Link>
              <Link to="/admin/listings" className="quick-action-card">
                <FaList />
                <span>Gérer les annonces</span>
              </Link>
              <Link to="/admin/orders" className="quick-action-card">
                <FaShoppingCart />
                <span>Gérer les commandes</span>
              </Link>
              <Link to="/admin/payments" className="quick-action-card">
                <FaCreditCard />
                <span>Gérer les paiements</span>
              </Link>
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}

// Helper function to get color for category bars
const getColorForIndex = (index) => {
  const colors = ["#00b894", "#0984e3", "#fdcb6e", "#e84393", "#6c5ce7"]
  return colors[index % colors.length]
}

export default AdminDashboard
