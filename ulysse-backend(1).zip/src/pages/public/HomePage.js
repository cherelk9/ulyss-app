"use client"

import { useState, useEffect } from "react"
import { Link } from "react-router-dom"
import { FaSearch, FaStar, FaMapMarkerAlt, FaPhone } from "react-icons/fa"
import { getAllCategories } from "../../services/listingService"
import { getFeaturedListings } from "../../services/listingService"
import "./HomePage.css"

const HomePage = () => {
  const [categories, setCategories] = useState([])
  const [featuredListings, setFeaturedListings] = useState([])
  const [searchQuery, setSearchQuery] = useState("")
  const [isLoading, setIsLoading] = useState(true)

  useEffect(() => {
    const fetchData = async () => {
      try {
        setIsLoading(true)
        const categoriesData = await getAllCategories()
        const featuredListingsData = await getFeaturedListings(6)

        setCategories(categoriesData)
        setFeaturedListings(featuredListingsData)
      } catch (error) {
        console.error("Error fetching data:", error)
      } finally {
        setIsLoading(false)
      }
    }

    fetchData()
  }, [])

  const handleSearch = (e) => {
    e.preventDefault()
    if (searchQuery.trim()) {
      window.location.href = `/search?q=${encodeURIComponent(searchQuery)}`
    }
  }

  return (
    <div className="home-page">
      {/* Hero Section */}
      <section className="hero-section">
        <div className="container">
          <div className="hero-content">
            <h1>Trouvez les meilleurs services pour votre séjour</h1>
            <p>Hébergements, transports, activités et bien plus encore</p>

            <form className="hero-search-form" onSubmit={handleSearch}>
              <div className="search-input-container">
                <input
                  type="text"
                  placeholder="Que recherchez-vous ?"
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                />
                <button type="submit">
                  <FaSearch /> Rechercher
                </button>
              </div>
            </form>
          </div>
        </div>
      </section>

      {/* Categories Section */}
      <section className="categories-section">
        <div className="container">
          <h2 className="section-title">Explorez par catégorie</h2>

          {isLoading ? (
            <div className="loading">Chargement des catégories...</div>
          ) : (
            <div className="categories-grid">
              {categories.map((category) => (
                <Link to={`/category/${category.id}`} key={category.id} className="category-card">
                  <div className="category-icon">
                    <i className={`fas fa-${category.icon}`}></i>
                  </div>
                  <h3>{category.name}</h3>
                  <p>{category.description}</p>
                </Link>
              ))}
            </div>
          )}
        </div>
      </section>

      {/* Featured Listings Section */}
      <section className="featured-listings-section">
        <div className="container">
          <h2 className="section-title">Services en vedette</h2>

          {isLoading ? (
            <div className="loading">Chargement des services en vedette...</div>
          ) : (
            <div className="listings-grid">
              {featuredListings.map((listing) => (
                <Link to={`/listings/${listing.id}`} key={listing.id} className="listing-card">
                  <div className="listing-image">
                    <img
                      src={
                        listing.images && listing.images.length > 0
                          ? listing.images[0].imageUrl
                          : "https://via.placeholder.com/300x200"
                      }
                      alt={listing.name}
                    />
                    <span className="listing-price">{listing.price} XOF</span>
                  </div>
                  <div className="listing-content">
                    <h3>{listing.name}</h3>
                    <div className="listing-meta">
                      <span className="listing-location">
                        <FaMapMarkerAlt /> {listing.location}
                      </span>
                      <span className="listing-rating">
                        <FaStar /> 4.8 (120)
                      </span>
                    </div>
                    <p className="listing-description">
                      {listing.description.length > 100
                        ? `${listing.description.substring(0, 100)}...`
                        : listing.description}
                    </p>
                    <div className="listing-contact">
                      <FaPhone /> {listing.ownerPhone}
                    </div>
                  </div>
                </Link>
              ))}
            </div>
          )}

          <div className="view-all-container">
            <Link to="/search" className="btn btn-outline-primary">
              Voir tous les services
            </Link>
          </div>
        </div>
      </section>

      {/* How It Works Section */}
      <section className="how-it-works-section">
        <div className="container">
          <h2 className="section-title">Comment ça marche</h2>

          <div className="steps-container">
            <div className="step">
              <div className="step-number">1</div>
              <h3>Recherchez</h3>
              <p>Trouvez le service qui correspond à vos besoins</p>
            </div>
            <div className="step">
              <div className="step-number">2</div>
              <h3>Réservez</h3>
              <p>Effectuez votre réservation en quelques clics</p>
            </div>
            <div className="step">
              <div className="step-number">3</div>
              <h3>Payez</h3>
              <p>Payez en toute sécurité via notre plateforme</p>
            </div>
            <div className="step">
              <div className="step-number">4</div>
              <h3>Profitez</h3>
              <p>Profitez de votre service et laissez un avis</p>
            </div>
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="cta-section">
        <div className="container">
          <div className="cta-content">
            <h2>Vous êtes un prestataire de services ?</h2>
            <p>Rejoignez notre plateforme et développez votre activité</p>
            <Link to="/register" className="btn btn-primary">
              Devenir partenaire
            </Link>
          </div>
        </div>
      </section>
    </div>
  )
}

export default HomePage
