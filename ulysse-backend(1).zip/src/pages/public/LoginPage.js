"use client"

import { useState } from "react"
import { Link, useNavigate } from "react-router-dom"
import { FaEnvelope, FaLock, FaEye, FaEyeSlash } from "react-icons/fa"
import { useAuth } from "../../contexts/AuthContext"
import "./AuthPages.css"

const LoginPage = () => {
  const [email, setEmail] = useState("")
  const [password, setPassword] = useState("")
  const [showPassword, setShowPassword] = useState(false)
  const [error, setError] = useState("")
  const [isLoading, setIsLoading] = useState(false)

  const { login } = useAuth()
  const navigate = useNavigate()

  const handleSubmit = async (e) => {
    e.preventDefault()

    if (!email || !password) {
      setError("Veuillez remplir tous les champs")
      return
    }

    try {
      setError("")
      setIsLoading(true)

      await login(email, password)

      // Redirect based on user role
      const user = JSON.parse(localStorage.getItem("user"))
      if (user.role === "admin") {
        navigate("/admin")
      } else if (user.role === "proprietaire") {
        navigate("/proprietaire/dashboard")
      } else {
        navigate("/client/dashboard")
      }
    } catch (error) {
      setError(error.message || "Échec de la connexion")
    } finally {
      setIsLoading(false)
    }
  }

  const togglePasswordVisibility = () => {
    setShowPassword(!showPassword)
  }

  // Demo login credentials
  const demoCredentials = [
    { role: "Client", email: "client@ulysse.com", password: "client123" },
    { role: "Propriétaire", email: "proprietaire@ulysse.com", password: "prop123" },
    { role: "Admin", email: "admin@ulysse.com", password: "admin123" },
  ]

  const handleDemoLogin = (demoEmail, demoPassword) => {
    setEmail(demoEmail)
    setPassword(demoPassword)
  }

  return (
    <div className="auth-page">
      <div className="container">
        <div className="auth-container">
          <div className="auth-form-container">
            <h2>Connexion</h2>
            <p>Connectez-vous pour accéder à votre compte</p>

            {error && <div className="alert alert-danger">{error}</div>}

            <form onSubmit={handleSubmit} className="auth-form">
              <div className="form-group">
                <label htmlFor="email">Email</label>
                <div className="input-with-icon">
                  <FaEnvelope className="input-icon" />
                  <input
                    type="email"
                    id="email"
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    placeholder="Votre email"
                    required
                  />
                </div>
              </div>

              <div className="form-group">
                <label htmlFor="password">Mot de passe</label>
                <div className="input-with-icon">
                  <FaLock className="input-icon" />
                  <input
                    type={showPassword ? "text" : "password"}
                    id="password"
                    value={password}
                    onChange={(e) => setPassword(e.target.value)}
                    placeholder="Votre mot de passe"
                    required
                  />
                  <button type="button" className="password-toggle" onClick={togglePasswordVisibility}>
                    {showPassword ? <FaEyeSlash /> : <FaEye />}
                  </button>
                </div>
              </div>

              <div className="form-group form-actions">
                <div className="remember-me">
                  <input type="checkbox" id="remember" />
                  <label htmlFor="remember">Se souvenir de moi</label>
                </div>
                <Link to="/forgot-password" className="forgot-password">
                  Mot de passe oublié ?
                </Link>
              </div>

              <button type="submit" className="btn btn-primary btn-block" disabled={isLoading}>
                {isLoading ? "Connexion en cours..." : "Se connecter"}
              </button>
            </form>

            <div className="auth-separator">
              <span>Ou</span>
            </div>

            <div className="demo-accounts">
              <h3>Comptes de démonstration</h3>
              <div className="demo-accounts-grid">
                {demoCredentials.map((demo, index) => (
                  <div key={index} className="demo-account">
                    <h4>{demo.role}</h4>
                    <p>Email: {demo.email}</p>
                    <p>Mot de passe: {demo.password}</p>
                    <button
                      type="button"
                      className="btn btn-outline-primary btn-sm"
                      onClick={() => handleDemoLogin(demo.email, demo.password)}
                    >
                      Utiliser ce compte
                    </button>
                  </div>
                ))}
              </div>
            </div>

            <div className="auth-footer">
              <p>
                Vous n'avez pas de compte ? <Link to="/register">Inscrivez-vous</Link>
              </p>
            </div>
          </div>

          <div className="auth-image">
            <div className="auth-image-content">
              <h2>Bienvenue sur ULYSSE</h2>
              <p>Votre plateforme de services pour organiser votre séjour en toute simplicité.</p>
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}

export default LoginPage
