package com.ulysse.listingservice.repository;

import com.ulysse.listingservice.model.Listing;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface ListingRepository extends JpaRepository<Listing, Long> {
    Page<Listing> findByStatus(String status, Pageable pageable);
    Page<Listing> findByOwnerId(Long ownerId, Pageable pageable);
    Page<Listing> findByOwnerIdAndStatus(Long ownerId, String status, Pageable pageable);
    Page<Listing> findByCategoryId(Long categoryId, Pageable pageable);
    
    @Query("SELECT l FROM Listing l WHERE l.status = 'APPROVED' AND " +
           "(LOWER(l.name) LIKE LOWER(CONCAT('%', :keyword, '%')) OR " +
           "LOWER(l.description) LIKE LOWER(CONCAT('%', :keyword, '%')))")
    Page<Listing> searchListings(String keyword, Pageable pageable);
    
    @Query("SELECT l FROM Listing l WHERE l.status = 'APPROVED' AND l.featured = true")
    List<Listing> findFeaturedListings(Pageable pageable);
}
