package com.ulysse.listingservice.controller;

import com.ulysse.listingservice.dto.ListingDTO;
import com.ulysse.listingservice.dto.ListingRequest;
import com.ulysse.listingservice.service.ListingService;
import jakarta.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import java.util.List;

@RestController
@RequestMapping("/api/listings")
public class ListingController {
    
    @Autowired
    private ListingService listingService;
    
    @GetMapping
    public ResponseEntity<Page<ListingDTO>> getAllListings(Pageable pageable) {
        return ResponseEntity.ok(listingService.getAllApprovedListings(pageable));
    }
    
    @GetMapping("/{id}")
    public ResponseEntity<ListingDTO> getListingById(@PathVariable Long id) {
        return ResponseEntity.ok(listingService.getListingById(id));
    }
    
    @PostMapping
    @PreAuthorize("hasRole('PROPRIETAIRE')")
    public ResponseEntity<ListingDTO> createListing(
            @Valid @RequestPart("listing") ListingRequest listingRequest,
            @RequestPart(value = "images", required = false) List<MultipartFile> images,
            @RequestPart(value = "documents", required = false) List<MultipartFile> documents) {
        return ResponseEntity.ok(listingService.createListing(listingRequest, images, documents));
    }
    
    @PutMapping("/{id}")
    @PreAuthorize("hasRole('PROPRIETAIRE')")
    public ResponseEntity<ListingDTO> updateListing(
            @PathVariable Long id,
            @Valid @RequestPart("listing") ListingRequest listingRequest,
            @RequestPart(value = "images", required = false) List<MultipartFile> images,
            @RequestPart(value = "documents", required = false) List<MultipartFile> documents) {
        return ResponseEntity.ok(listingService.updateListing(id, listingRequest, images, documents));
    }
    
    @DeleteMapping("/{id}")
    @PreAuthorize("hasRole('PROPRIETAIRE') or hasRole('ADMIN')")
    public ResponseEntity<?> deleteListing(@PathVariable Long id) {
        listingService.deleteListing(id);
        return ResponseEntity.ok().build();
    }
    
    @GetMapping("/owner")
    @PreAuthorize("hasRole('PROPRIETAIRE')")
    public ResponseEntity<Page<ListingDTO>> getOwnerListings(Pageable pageable) {
        return ResponseEntity.ok(listingService.getOwnerListings(pageable));
    }
    
    @GetMapping("/category/{categoryId}")
    public ResponseEntity<Page<ListingDTO>> getListingsByCategory(
            @PathVariable Long categoryId, Pageable pageable) {
        return ResponseEntity.ok(listingService.getListingsByCategory(categoryId, pageable));
    }
    
    @GetMapping("/search")
    public ResponseEntity<Page<ListingDTO>> searchListings(
            @RequestParam String keyword, Pageable pageable) {
        return ResponseEntity.ok(listingService.searchListings(keyword, pageable));
    }
    
    @GetMapping("/featured")
    public ResponseEntity<List<ListingDTO>> getFeaturedListings() {
        return ResponseEntity.ok(listingService.getFeaturedListings());
    }
    
    @PutMapping("/{id}/status")
    @PreAuthorize("hasRole('ADMIN')")
    public ResponseEntity<ListingDTO> updateListingStatus(
            @PathVariable Long id,
            @RequestParam String status,
            @RequestParam(required = false) String rejectionReason) {
        return ResponseEntity.ok(listingService.updateListingStatus(id, status, rejectionReason));
    }
    
    @PutMapping("/{id}/featured")
    @PreAuthorize("hasRole('ADMIN')")
    public ResponseEntity<ListingDTO> toggleFeaturedStatus(
            @PathVariable Long id,
            @RequestParam boolean featured) {
        return ResponseEntity.ok(listingService.toggleFeaturedStatus(id, featured));
    }
}
