package com.ulysse.orderservice.controller;

import com.ulysse.orderservice.dto.OrderDTO;
import com.ulysse.orderservice.dto.OrderRequest;
import com.ulysse.orderservice.dto.PaymentRequest;
import com.ulysse.orderservice.service.OrderService;
import jakarta.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/orders")
public class OrderController {
    
    @Autowired
    private OrderService orderService;
    
    @PostMapping
    @PreAuthorize("hasRole('CLIENT')")
    public ResponseEntity<OrderDTO> createOrder(@Valid @RequestBody OrderRequest orderRequest) {
        return ResponseEntity.ok(orderService.createOrder(orderRequest));
    }
    
    @GetMapping("/{id}")
    @PreAuthorize("hasRole('CLIENT') or hasRole('PROPRIETAIRE') or hasRole('ADMIN')")
    public ResponseEntity<OrderDTO> getOrderById(@PathVariable Long id) {
        return ResponseEntity.ok(orderService.getOrderById(id));
    }
    
    @GetMapping("/client")
    @PreAuthorize("hasRole('CLIENT')")
    public ResponseEntity<Page<OrderDTO>> getClientOrders(Pageable pageable) {
        return ResponseEntity.ok(orderService.getClientOrders(pageable));
    }
    
    @GetMapping("/proprietaire")
    @PreAuthorize("hasRole('PROPRIETAIRE')")
    public ResponseEntity<Page<OrderDTO>> getProprietaireOrders(Pageable pageable) {
        return ResponseEntity.ok(orderService.getProprietaireOrders(pageable));
    }
    
    @GetMapping("/admin")
    @PreAuthorize("hasRole('ADMIN')")
    public ResponseEntity<Page<OrderDTO>> getAllOrders(
            @RequestParam(required = false) String status, Pageable pageable) {
        if (status != null) {
            return ResponseEntity.ok(orderService.getOrdersByStatus(status, pageable));
        }
        return ResponseEntity.ok(orderService.getAllOrders(pageable));
    }
    
    @PostMapping("/{id}/pay")
    @PreAuthorize("hasRole('CLIENT')")
    public ResponseEntity<OrderDTO> processPayment(
            @PathVariable Long id, @Valid @RequestBody PaymentRequest paymentRequest) {
        return ResponseEntity.ok(orderService.processPayment(id, paymentRequest));
    }
    
    @PutMapping("/{id}/complete")
    @PreAuthorize("hasRole('ADMIN')")
    public ResponseEntity<OrderDTO> completeOrder(@PathVariable Long id) {
        return ResponseEntity.ok(orderService.completeOrder(id));
    }
    
    @PutMapping("/{id}/cancel")
    @PreAuthorize("hasRole('CLIENT') or hasRole('ADMIN')")
    public ResponseEntity<OrderDTO> cancelOrder(@PathVariable Long id) {
        return ResponseEntity.ok(orderService.cancelOrder(id));
    }
}
