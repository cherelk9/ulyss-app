package com.ulysse.orderservice.model;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.math.BigDecimal;
import java.time.LocalDateTime;

@Entity
@Table(name = "orders")
@Data
@NoArgsConstructor
@AllArgsConstructor
public class Order {
    
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    
    @Column(nullable = false)
    private Long clientId;
    
    @Column(nullable = false)
    private String clientName;
    
    @Column(nullable = false)
    private Long proprietaireId;
    
    @Column(nullable = false)
    private String proprietaireName;
    
    @Column(nullable = false)
    private Long listingId;
    
    @Column(nullable = false)
    private String listingName;
    
    @Column(nullable = false)
    private BigDecimal amount;
    
    @Column(nullable = false)
    private BigDecimal commissionAmount;
    
    @Column(nullable = false)
    private String status; // PENDING, PAID, COMPLETED, CANCELLED
    
    @Column(nullable = false)
    private String paymentMethod;
    
    @Column
    private String paymentReference;
    
    @Column(nullable = false)
    private LocalDateTime orderDate;
    
    @Column
    private LocalDateTime paymentDate;
    
    @Column
    private LocalDateTime completionDate;
    
    @PrePersist
    protected void onCreate() {
        orderDate = LocalDateTime.now();
        status = "PENDING";
    }
}
